Fs = 360;          
t = 0:1/Fs:10;         
pureECG = 1.5 * sin(2*pi*1.7*t);        
noise50Hz = 0.5 * sin(2*pi*50*t);       
randomNoise = 0.2 * randn(size(t));     
ecg = pureECG + noise50Hz + randomNoise;  
figure;
subplot(2,1,1);
plot(t, ecg);
title('Original Noisy ECG Signal');
xlabel('Time (s)');
ylabel('Amplitude');
bpFilt = designfilt('bandpassfir','FilterOrder',100, ...
         'CutoffFrequency1',0.5,'CutoffFrequency2',40, ...
         'SampleRate',Fs);
ecgFiltered = filter(bpFilt, ecg);
subplot(2,1,2);
plot(t, ecgFiltered);
title('Filtered ECG Signal (0.5 – 40 Hz)');
xlabel('Time (s)');
ylabel('Amplitude');
